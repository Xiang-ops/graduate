package com.xx.order.utils;

import com.xx.order.model.Point;
import com.xx.order.service.PointService;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AddPointUtil {
    @Autowired
    private static PointService pointService;

}
